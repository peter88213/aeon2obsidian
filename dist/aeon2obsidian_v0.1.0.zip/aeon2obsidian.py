#!/usr/bin/python3
"""Convert Aeon Timeline 2 project data to Obsidian Markdown fileset. 

usage: aeon2obsidian.py Sourcefile

positional arguments:
  Sourcefile  The path of the .aeon file.

Copyright (c) 2024 Peter Triesberger
For further information see https://github.com/peter88213/aeon2obsidian
Published under the MIT License (https://opensource.org/licenses/mit-license.php)
"""
import os
import sys
import json
import codecs
import zipfile


def open_timeline(filePath):
    """Unzip the project file and read 'timeline.json'.

    Positional arguments:
        filePath -- Path of the .aeon project file to read.
        
    Return a Python object containing the timeline structure.
    Raise the "Error" exception in case of error. 
    """
    with zipfile.ZipFile(filePath, 'r') as myzip:
        jsonBytes = myzip.read('timeline.json')
        jsonStr = codecs.decode(jsonBytes, encoding='utf-8')
    if not jsonStr:
        raise ValueError('No JSON part found in timeline data.')
    jsonData = json.loads(jsonStr)
    return jsonData

from datetime import datetime
from datetime import timedelta
from datetime import date


class Aeon2File:

    def __init__(self, filePath):
        """Set the Aeon 2 project file path."""
        self.filePath = filePath
        self.types = {}
        self.roles = {}
        self.entities = {}

        self.items = {}
        self.labels = {}
        self.itemIndex = {}
        self.relationships = {}
        self.tags = {}
        self.narrative = {}

    def read(self):
        """Read the Aeon 2 project file.
        
        Store the relevant data in the items dictionary.
        Populate the labels dictionary.
        Populate the itemIndex dictionary.
        
        Return a success message.
        """

        def add_label(key, value):
            """Add an entry to the labels dictionary, handling multiple labels."""
            if value in labelText:
                print(f'Multiple label: {value}')
                number = labelText[value] + 1
                labelText[value] = number
                value = f'{value}({number})'
            else:
                labelText[value] = 0
            self.labels[key] = value

        #--- Read the aeon file and get a JSON data structure.
        jsonData = open_timeline(self.filePath)
        labelText = {}

        #--- Create a labels dictionary for types and relationships.
        for aeonType in jsonData['template']['types']:
            uid = aeonType['guid']
            item = aeonType.get('name', '').strip()
            if item:
                add_label(uid, item)
            for role in aeonType['roles']:
                add_label(role['guid'], role['name'])
            return
        for uid in jsonData['template']['references']:
            reference = jsonData['template']['references'][uid].get('name', '').strip()
            if reference:
                self.labels[uid] = reference

        #--- Create a data model and extend the labels dictionary.
        for uid in jsonData['data']['items']:
            aeonItem = jsonData['data']['items'][uid]
            add_label(uid, aeonItem['name'].strip())
            self.items[uid] = self._get_item(aeonItem)

        #--- Create an index.
        for uid in jsonData['data']['items']['allIdsForType']:
            itemUidList = jsonData['data']['items']['allIdsForType'][uid]
            self.itemIndex[uid] = itemUidList

        #--- Create a relationships dictionary.
        for uid in jsonData['data']['relationships']:
            refId = jsonData['data']['relationships'][uid]['reference']
            objId = jsonData['data']['relationships'][uid]['object']
            self.relationships[uid] = (refId, objId)

        #--- Get the narrative tree.
        self.narrative = jsonData['data'].get('narrative', self.narrative)

        return 'Aeon 2 file successfully read.'

    def _get_date(self, aeonItem):
        timestamp = aeonItem['startDate'].get('timestamp', 'null')
        if timestamp and timestamp != 'null':
            startDateTime = datetime.min + timedelta(seconds=timestamp)
            dateStr = date.isoformat(startDateTime)
        else:
            dateStr = ''
        return dateStr

    def _get_duration(self, aeonItem):
        durationList = []
        durationDict = aeonItem.get('duration', None)
        if durationDict:
            durations = list(durationDict)
            for unit in durations:
                if durationDict[unit]:
                    durationList.append(f'{durationDict[unit]} {unit}')
        durationStr = ', '.join(durationList)
        return durationStr

    def _get_item(self, aeonItem):
        """Return a dictionary with the relevant item properties."""
        item = {}
        item['shortLabel'] = aeonItem['shortLabel']
        item['summary'] = aeonItem['summary']
        item['references'] = aeonItem['references']
        item['children'] = aeonItem['children']

        # Read tags.
        tags = []
        for tag in aeonItem['tags']:
            tags.append(f"#{tag.strip().replace(' ','_')}")
            item['tags'] = tags

        # Read date/time/duration.
        dateStr = self._get_date(aeonItem)
        if dateStr:
            item['Date'] = dateStr
        timeStr = self._get_time(aeonItem)
        if timeStr:
            item['Time'] = timeStr
        durationStr = self._get_duration(aeonItem)
        if durationStr:
            item['Duration'] = durationStr

        return item

    def _get_time(self, aeonItem):
        timestamp = aeonItem['startDate'].get('timestamp', 'null')
        if timestamp and timestamp != 'null':
            startDateTime = datetime.min + timedelta(seconds=timestamp)
            timeStr = startDateTime.strftime('%X')
            seconds = aeonItem['startDate'].get('second', 0)
            if not seconds:
                h, m, _ = timeStr.split(':')
                timeStr = ':'.join([h, m])
        else:
            timeStr = ''
        return timeStr



class ObsidianFiles:
    FORBIDDEN_CHARACTERS = ('\\', '/', ':', '*', '?', '"', '<', '>', '|')
    # set of characters that filenames cannot contain

    def __init__(self, folderPath):
        """Set the Obsidian folder."""
        self.folderPath = folderPath
        self.items = {}
        self.labels = {}
        self.itemIndex = {}
        self.relationships = {}
        self.narrative = {}

    def write(self):
        """Create a set of Markdown files in the Obsidian folder.
        
        Return a success message.
        """
        os.makedirs(self.folderPath, exist_ok=True)
        for uid in self.items:
            title = self._strip_title(self.labels[uid])
            text = self._build_content(self.items[uid])
            self._write_file(f'{self.folderPath}/{title}.md', text)
        self._build_index()
        self._build_narrative()
        return 'Obsidian files successfully written.'

    def _build_content(self, item):
        """Return a string with the Markdown file content.
        
        Positional arguments:
            item: dictionary of Aeon item properties.
        """
        lines = []
        for uid in item:
            itemProperty = item[uid]
            if itemProperty:
                if type(itemProperty) == str:
                    lines.append(self._to_markdown(itemProperty))
                else:
                    for element in itemProperty:
                        if element in self.relationships:
                            refId, objId = self.relationships[element]
                            linkLabel = self.labels[refId]
                            link = self._strip_title(self.labels[objId])
                            line = f'- {linkLabel}: [[{link}]]'
                            lines.append(line)
                        else:
                            link = self._strip_title(self.labels.get(element, ''))
                            if link:
                                lines.append(f'[[{link}]]')
                            else:
                                lines.append(self._to_markdown(element))

        return '\n\n'.join(lines)

    def _build_index(self):
        """Create index pages."""
        mainIndexlines = []
        for uid in self.itemIndex:
            itemType = f'_{self._strip_title(self.labels[uid])}'
            mainIndexlines.append(f'- [[{itemType}]]')
            itemUidList = self.itemIndex[uid]

            # Create an index file with the items of the type.
            lines = []
            for itemUid in itemUidList:
                itemLabel = self._strip_title(self.labels[itemUid])
                lines.append(f'- [[{itemLabel}]]')
            text = '\n'.join(lines)
            self._write_file(f'{self.folderPath}/{itemType}.md', text)

        # Create a main index file with the types.
        text = '\n'.join(mainIndexlines)
        self._write_file(f'{self.folderPath}/__index.md', text)

    def _build_narrative(self):
        """Create a page with the narrative tree."""

        def get_branch(root, level):
            level += 1
            uid = root['id']
            if uid in self.labels:
                link = self._strip_title(self.labels[uid])
                lines.append(f"{'#' * level} [[{link}]]")
            for branch in root['children']:
                get_branch(branch, level)

        lines = []
        get_branch(self.narrative, 1)
        text = '\n\n'.join(lines)
        self._write_file(f'{self.folderPath}/__narrative.md', text)

    def _strip_title(self, title):
        """Return title with characters removed that must not appear in a file name."""
        for c in self.FORBIDDEN_CHARACTERS:
            title = title.replace(c, '')
        return title

    def _to_markdown(self, text):
        """Return text with double linebreaks."""
        return text.replace('\n', '\n\n')

    def _write_file(self, filePath, text):
        """Write a single file and create a backup copy, if applicable.
        
        Positional arguments:
            filePath: str -- Path of the file to write.
            text: str -- File content.
        """
        backedUp = False
        if os.path.isfile(filePath):
            try:
                os.replace(filePath, f'{filePath}.bak')
                backedUp = True
            except Exception as ex:
                raise Exception(f'Error: Cannot overwrite "{os.path.normpath(filePath)}": {str(ex)}.')

        try:
            with open(filePath, 'w', encoding='utf-8') as f:
                f.write(text)
        except Exception as ex:
            if backedUp:
                os.replace(f'{filePath}.bak', self.filePath)
            raise Exception(f'Error: Cannot write "{os.path.normpath(filePath)}": {str(ex)}.')

        return f'"{os.path.normpath(filePath)}" written.'



def main(sourcePath):
    """Convert an .aeon source file to a set of Markdown files.
    
    Positional arguments:
        sourcePath -- str: The path of the .aeon file.
    """

    # Create an Aeon 2 file object and read the data.
    aeon3File = Aeon2File(sourcePath)
    print(aeon3File.read())
    return

    # Define the output directory.
    aeonDir, aeonFilename = os.path.split(sourcePath)
    projectName = os.path.splitext(aeonFilename)[0]
    obsidianFolder = os.path.join(aeonDir, projectName)

    # Create an Obsidian fileset object and write the data.
    obsidianFiles = ObsidianFiles(obsidianFolder)
    obsidianFiles.items = aeon3File.items
    obsidianFiles.labels = aeon3File.labels
    obsidianFiles.itemIndex = aeon3File.itemIndex
    obsidianFiles.relationships = aeon3File.relationships
    obsidianFiles.narrative = aeon3File.narrative
    print(obsidianFiles.write())


if __name__ == '__main__':
    main(sys.argv[1])
